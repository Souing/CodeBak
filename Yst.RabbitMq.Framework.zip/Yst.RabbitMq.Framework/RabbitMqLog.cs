﻿using NLog;
using Yst.Framework.Logging;

namespace Yst.Framework.RabbitMq
{
    /// <summary>
    /// 功能描述：RabbitMq 
    /// 创 建 者：
    /// 审 查 者：        审查时间:       
    /// </summary>
    public class RabbitMqLog
    {
        /// <summary>
        /// 日志记录器
        /// </summary>
        internal static readonly LogHelp Logger = new LogHelp();

        /// <summary>
        /// EasyNetQ日志
        /// </summary>
        internal static readonly LogHelp EasyNetQLogger = new LogHelp("EasyNetQ");

        //internal static readonly NLog.Logger EasyNetQLogger = LogManager.GetLogger("EasyNetQ");
    }
}
