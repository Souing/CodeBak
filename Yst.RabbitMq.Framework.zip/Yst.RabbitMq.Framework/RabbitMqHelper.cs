﻿using EasyNetQ;
using EasyNetQ.Consumer;
using EasyNetQ.FluentConfiguration;
using EasyNetQ.Scheduling;
using Newtonsoft.Json;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Yst.Framework.RabbitMq
{
    public class RabbitMqHelper
    {
        public static readonly IBus PublicBus = BusBuilder.CreateMessageBus();
        private const string ReciveLogSucessFormat = "{0}---{1}---{2}---处理结果:{3}---receiveMsg:{4}";
        private const string ReciveLogFailFormat = "{0}---{1}---{2}---receiveMsg:{3}---errorMsg:{4}";
        private const string SendLogSucessFormat = "{0}---{1}---{2}---发送结果:{3}---publicMsg:{4}";
        private const string SendLogFailFormat = "{0}---{1}---{2}---sendMsg:{3}---errorMsg:{4}";
        private const string SuccessMsg = "成功";
        private const string FailMsg = "失败";
        private const string DateFormat = "yyyy-MM-dd HH:mm:ss fff";

        /// <summary>
        /// 发送消息
        /// </summary>
        public static void Publish<T>(T msg, string topic = "") where T : class
        {
            string guid = Guid.NewGuid().ToString("N");
            string result;
            string beginDate = DateTime.Now.ToString(DateFormat);
            try
            {
                PublicBus.Publish(msg, p => p.WithTopic(topic));
                result = SuccessMsg;
            }
            catch (EasyNetQException ex)
            {
                result = FailMsg;
                RabbitMqLog.Logger.Error(SendLogFailFormat, beginDate, DateTime.Now.ToString(DateFormat), guid, JsonConvert.SerializeObject(result), JsonConvert.SerializeObject(ex));
                //处理连接消息服务器异常 
            }
            RabbitMqLog.Logger.Info(SendLogSucessFormat, beginDate,DateTime.Now.ToString(DateFormat), guid, result, JsonConvert.SerializeObject(msg));
        }

        /// <summary>
        /// 发送消息
        /// </summary>
        public static void Publish<T>(T msg, Action<IPublishConfiguration> config) where T : class
        {
            string guid = Guid.NewGuid().ToString("N");
            string result;
            string beginDate = DateTime.Now.ToString(DateFormat);
            try
            {
                PublicBus.Publish(msg, config);
                result = SuccessMsg;
            }
            catch (EasyNetQException ex)
            {
                result = FailMsg;
                RabbitMqLog.Logger.Error(SendLogFailFormat, beginDate, DateTime.Now.ToString(DateFormat), guid, JsonConvert.SerializeObject(result), JsonConvert.SerializeObject(ex));
                //处理连接消息服务器异常 
            }
            RabbitMqLog.Logger.Info(SendLogSucessFormat, beginDate, DateTime.Now.ToString(DateFormat), guid, result, JsonConvert.SerializeObject(msg));
        }

        /// <summary>
        /// 延迟发送消息
        /// </summary>
        public static void DelayPublish<T>(T msg, TimeSpan messageDelay, string topic = "") where T : class
        {
            string guid = Guid.NewGuid().ToString("N");
            string result;
            string beginDate = DateTime.Now.ToString(DateFormat);
            try
            {
                PublicBus.FuturePublish(messageDelay, msg, topic);
                result = SuccessMsg;
            }
            catch (EasyNetQException ex)
            {
                result = FailMsg;
                RabbitMqLog.Logger.Error(SendLogFailFormat, beginDate, DateTime.Now.ToString(DateFormat), guid, JsonConvert.SerializeObject(result), JsonConvert.SerializeObject(ex));
                //处理连接消息服务器异常 
            }
            RabbitMqLog.Logger.Info(SendLogSucessFormat, beginDate, DateTime.Now.ToString(DateFormat), guid, result, JsonConvert.SerializeObject(msg));
        }

        /// <summary>
        /// 接收消息
        /// </summary>
        public static void Subscribe<T>(Action<T> action) where T : class ,new()
        {
            try
            {
                for (int i = 0; i < BusBuilder.ThreadCount; i++)
                {
                    PublicBus.SubscribeAsync<T>("", message => Task.Run(() =>
                    {
                        string guid = Guid.NewGuid().ToString("N");
                        string result;
                        string beginDate = DateTime.Now.ToString(DateFormat);
                        try
                        {
                            action(message);
                            result = SuccessMsg;
                        }
                        catch (Exception ex)
                        {
                            result = FailMsg;
                            RabbitMqLog.Logger.Error(ReciveLogFailFormat, beginDate, DateTime.Now.ToString(DateFormat), guid, JsonConvert.SerializeObject(result), JsonConvert.SerializeObject(ex));
                        }
                        RabbitMqLog.Logger.Info(ReciveLogSucessFormat, beginDate,DateTime.Now.ToString(DateFormat), guid, result, JsonConvert.SerializeObject(message));
                    }));
                }
            }
            catch (EasyNetQException ex)
            {
                RabbitMqLog.Logger.Error(string.Format("subscribeMsg:{0}------>errorMsg:{1}------>errorException:{2}------>errorStackTrace:{3}", "", ex.Message, ex.InnerException, ex.StackTrace));
                //处理连接消息服务器异常 
            }
        }


        /// <summary>
        /// 接收消息
        /// </summary>
        public static void Subscribe<T>(string subscriptionid, Action<T> action) where T : class ,new()
        {
            try
            {
                for (int i = 0; i < BusBuilder.ThreadCount; i++)
                {
                    PublicBus.SubscribeAsync<T>(subscriptionid, message => Task.Run(() =>
                    {
                        string guid = Guid.NewGuid().ToString("N");
                        string result;
                        string beginDate = DateTime.Now.ToString(DateFormat);
                        try
                        {
                            action(message);
                            result = SuccessMsg;
                        }
                        catch (Exception ex)
                        {
                            result = FailMsg;
                            RabbitMqLog.Logger.Error(ReciveLogFailFormat, beginDate, DateTime.Now.ToString(DateFormat), guid, JsonConvert.SerializeObject(result), JsonConvert.SerializeObject(ex));
                        }
                        RabbitMqLog.Logger.Info(ReciveLogSucessFormat, beginDate, DateTime.Now.ToString(DateFormat), guid, result, JsonConvert.SerializeObject(message));
                    }));
                }
            }
            catch (EasyNetQException ex)
            {
                RabbitMqLog.Logger.Error(string.Format("subscribeMsg:{0}------>errorMsg:{1}------>errorException:{2}------>errorStackTrace:{3}", "", ex.Message, ex.InnerException, ex.StackTrace));
                //处理连接消息服务器异常 
            }
        }

        /// <summary>
        /// 接收消息
        /// </summary>
        public static void Subscribe<T>(Action<T> action, Action<ISubscriptionConfiguration> config) where T : class ,new()
        {
            try
            {
                for (int i = 0; i < BusBuilder.ThreadCount; i++)
                {
                    PublicBus.SubscribeAsync<T>("", message => Task.Run(() =>
                    {
                        string guid = Guid.NewGuid().ToString("N");
                        string result;
                        string beginDate = DateTime.Now.ToString(DateFormat);
                        try
                        {
                            action(message);
                            result = SuccessMsg;
                        }
                        catch (Exception ex)
                        {
                            result = FailMsg;
                            RabbitMqLog.Logger.Error(ReciveLogFailFormat, beginDate, DateTime.Now.ToString(DateFormat), guid, JsonConvert.SerializeObject(result), JsonConvert.SerializeObject(ex));
                        }
                        RabbitMqLog.Logger.Info(ReciveLogSucessFormat, beginDate, DateTime.Now.ToString(DateFormat), guid, result, JsonConvert.SerializeObject(message));
                    }), config);
                }
            }
            catch (EasyNetQException ex)
            {
                //处理连接消息服务器异常 
                RabbitMqLog.Logger.Error(string.Format("subscribeMsg:{0}------>errorMsg:{1}------>errorException:{2}------>errorStackTrace:{3}", "", ex.Message, ex.InnerException, ex.StackTrace));
            }
        }

        /// <summary>
        /// 接收消息
        /// </summary>
        public static void Subscribe<T>(string subscriptionid, string topic, Action<T> action) where T : class ,new()
        {
            try
            {
                for (int i = 0; i < BusBuilder.ThreadCount; i++)
                {
                    PublicBus.SubscribeAsync<T>(subscriptionid, message => Task.Run(() =>
                    {
                        string guid = Guid.NewGuid().ToString("N");
                        string result;
                        string beginDate = DateTime.Now.ToString(DateFormat);
                        try
                        {
                            action(message);
                            result = SuccessMsg;
                        }
                        catch (Exception ex)
                        {
                            result = FailMsg;
                            RabbitMqLog.Logger.Error(ReciveLogFailFormat, beginDate, DateTime.Now.ToString(DateFormat), guid, JsonConvert.SerializeObject(result), JsonConvert.SerializeObject(ex));
                        }
                        RabbitMqLog.Logger.Info(ReciveLogSucessFormat, beginDate, DateTime.Now.ToString(DateFormat), guid, result, JsonConvert.SerializeObject(message));
                    }),
                        p => p.WithTopic(topic));
                }
            }
            catch (EasyNetQException ex)
            {
                //处理连接消息服务器异常 
                RabbitMqLog.Logger.Error(string.Format("subscribeMsg:{0}------>errorMsg:{1}------>errorException:{2}------>errorStackTrace:{3}", "", ex.Message, ex.InnerException, ex.StackTrace));
            }
        }

        /// <summary>
        /// 接收消息
        /// </summary>
        public static void Subscribe<T>(string subscriptionid, Action<T> action, Action<ISubscriptionConfiguration> config) where T : class ,new()
        {
            try
            {
                for (int i = 0; i < BusBuilder.ThreadCount; i++)
                {
                    PublicBus.SubscribeAsync<T>(subscriptionid, message => Task.Run(() =>
                    {
                        string guid = Guid.NewGuid().ToString("N");
                        string result;
                        string beginDate = DateTime.Now.ToString(DateFormat);
                        try
                        {
                            action(message);
                            result = SuccessMsg;
                        }
                        catch (Exception ex)
                        {
                            result = FailMsg;
                            RabbitMqLog.Logger.Error(ReciveLogFailFormat, beginDate, DateTime.Now.ToString(DateFormat), guid, JsonConvert.SerializeObject(result), JsonConvert.SerializeObject(ex));
                        }
                        RabbitMqLog.Logger.Info(ReciveLogSucessFormat, beginDate, DateTime.Now.ToString(DateFormat), guid, result, JsonConvert.SerializeObject(message));
                    }), config);
                }
            }
            catch (EasyNetQException ex)
            {
                //处理连接消息服务器异常 
                RabbitMqLog.Logger.Error(string.Format("subscribeMsg:{0}------>errorMsg:{1}------>errorException:{2}------>errorStackTrace:{3}", "", ex.Message, ex.InnerException, ex.StackTrace));
            }
        }

        /// <summary>
        /// 接收消息
        /// 应用场景：满足不是easynet创建的队列
        /// </summary>
        public static Task SendAsync<T>(string queues, T msg) where T : class ,new()
        {
            if (string.IsNullOrEmpty(queues))
            {
                throw new Exception("对列名不能为空");
            }
            string guid = Guid.NewGuid().ToString("N");
            string result;
            string beginDate = DateTime.Now.ToString(DateFormat);
            try
            {
                result = SuccessMsg;
                RabbitMqLog.Logger.Info(SendLogSucessFormat, beginDate, DateTime.Now.ToString(DateFormat), guid, result, JsonConvert.SerializeObject(msg));
                return PublicBus.SendAsync(queues, msg);
            }
            catch (EasyNetQException ex)
            {
                result = FailMsg;
                RabbitMqLog.Logger.Error(SendLogFailFormat, beginDate, DateTime.Now.ToString(DateFormat), guid, JsonConvert.SerializeObject(result), JsonConvert.SerializeObject(ex));
                //处理连接消息服务器异常 
            }
            return null;
        }

        /// <summary>
        /// 接收消息
        /// 应用场景：满足不是easynet创建的队列
        /// </summary>
        public static void Send<T>(string queues, T msg) where T : class ,new()
        {
            if (string.IsNullOrEmpty(queues))
            {
                throw new Exception("对列名不能为空");
            }
            string guid = Guid.NewGuid().ToString("N");
            string result;
            string beginDate = DateTime.Now.ToString(DateFormat);
            try
            {
                result = SuccessMsg;
                PublicBus.Send(queues, msg);
            }
            catch (EasyNetQException ex)
            {
                result = FailMsg;
                RabbitMqLog.Logger.Error(SendLogFailFormat, beginDate, DateTime.Now.ToString(DateFormat), guid, JsonConvert.SerializeObject(result), JsonConvert.SerializeObject(ex));
            }
            RabbitMqLog.Logger.Info(SendLogSucessFormat, beginDate, DateTime.Now.ToString(DateFormat), guid, result, JsonConvert.SerializeObject(msg));
        }

        /// <summary>
        /// 接收消息
        /// 应用场景：满足不是easynet创建的队列
        /// </summary>
        public static void Receive<T>(string queues, Action<T> action, Action<IConsumerConfiguration> config = null) where T : class ,new()
        {
            if (string.IsNullOrEmpty(queues))
            {
                throw new Exception("对列名不能为空");
            }

            try
            {
                if (BusBuilder.ThreadCount == 1)
                {
                    PublicBus.Receive<T>(queues, (message) =>
                    {
                        string guid = Guid.NewGuid().ToString("N");
                        string result;
                        string beginDate = DateTime.Now.ToString(DateFormat);
                        try
                        {
                            action(message);
                            result = SuccessMsg;
                        }
                        catch (Exception ex)
                        {
                            result = FailMsg;
                            RabbitMqLog.Logger.Error(ReciveLogFailFormat, beginDate, DateTime.Now.ToString(DateFormat), guid, JsonConvert.SerializeObject(result), JsonConvert.SerializeObject(ex));
                        }
                        RabbitMqLog.Logger.Info(ReciveLogSucessFormat, beginDate, DateTime.Now.ToString(DateFormat), guid, result, JsonConvert.SerializeObject(message));
                    });
                }
                else
                {
                    if (config != null)
                    {

                        for (var i = 0; i < BusBuilder.ThreadCount; i++)
                        {
                            PublicBus.Receive<T>(queues,
                                message => Task.Run(
                                    () =>
                                    {
                                        string guid = Guid.NewGuid().ToString("N");
                                        string result;
                                        string beginDate = DateTime.Now.ToString(DateFormat);
                                        try
                                        {
                                            action(message);
                                            result = SuccessMsg;
                                        }
                                        catch (Exception ex)
                                        {
                                            result = FailMsg;
                                            RabbitMqLog.Logger.Error(ReciveLogFailFormat, beginDate, DateTime.Now.ToString(DateFormat), guid, JsonConvert.SerializeObject(result), JsonConvert.SerializeObject(ex));
                                        }
                                        RabbitMqLog.Logger.Info(ReciveLogSucessFormat, beginDate, DateTime.Now.ToString(DateFormat), guid, result, JsonConvert.SerializeObject(message));
                                    }), config);
                        }
                    }
                    else
                    {
                        for (var i = 0; i < BusBuilder.ThreadCount; i++)
                        {
                            PublicBus.Receive<T>(queues,
                                message => Task.Run(
                                    () =>
                                    {
                                        string guid = Guid.NewGuid().ToString("N");
                                        string result;
                                        string beginDate = DateTime.Now.ToString(DateFormat);
                                        try
                                        {
                                            action(message);
                                            result = SuccessMsg;
                                        }
                                        catch (Exception ex)
                                        {
                                            result = FailMsg;
                                            RabbitMqLog.Logger.Error(ReciveLogFailFormat, beginDate, DateTime.Now.ToString(DateFormat), guid, JsonConvert.SerializeObject(result), JsonConvert.SerializeObject(ex));
                                        }
                                        RabbitMqLog.Logger.Info(ReciveLogSucessFormat, beginDate, DateTime.Now.ToString(DateFormat), guid, result, JsonConvert.SerializeObject(message));
                                    }));
                        }
                    }
                }
            }
            catch (EasyNetQException ex)
            {
                //处理连接消息服务器异常 
                RabbitMqLog.Logger.Error(string.Format("receiveMsg:{0}------>errorMsg:{1}------>errorException:{2}------>errorStackTrace:{3}", "", ex.Message, ex.InnerException, ex.StackTrace));
            }
        }


        static readonly IConnection RabbitMqConn = RabbitMqClinetConnection.CreateConnection();

        public static void send(string queueName)
        {
            var model= RabbitMqConn.CreateModel();

            var arguments = new Dictionary<string, object>();
            model.QueueDeclare(queueName, false, false, false, arguments);
            byte[] messageBodyBytes = System.Text.Encoding.UTF8.GetBytes("Hello, world!");
            IBasicProperties props = model.CreateBasicProperties();
            props.Type = "Yst.Framework.RabbitMq";
            props.DeliveryMode = 2;
            props.CorrelationId = Guid.NewGuid().ToString();
            model.BasicPublish("", queueName, props, messageBodyBytes);

            //RabbitMqConn.Dispose();
        }

        public static void sendTopic(string exchangeName, string routing_key, string me)
        {
            var model = RabbitMqConn.CreateModel();
            model.ExchangeDeclare(exchangeName, ExchangeType.Topic);

            byte[] messageBodyBytes = Encoding.UTF8.GetBytes(me);
            model.BasicPublish(exchangeName, routing_key, null, messageBodyBytes);
        }

        public static void reciveTopic(string exchangeName, string routing_key)
        {
            var model = RabbitMqConn.CreateModel();
            model.ExchangeDeclare(exchangeName, ExchangeType.Topic);
            model.QueueDeclare(exchangeName + routing_key, false, false, false, null);
            model.QueueBind(exchangeName + routing_key, exchangeName, routing_key, null);

            EventingBasicConsumer consumer = new EventingBasicConsumer(model);
            consumer.Received += (ch, ea) => {
                var body = Encoding.UTF8.GetString(ea.Body);
                Console.WriteLine(DateTime.Now.ToString() + body);
                // ... process the message
                model.BasicAck(ea.DeliveryTag, false);
            };
            string consumerTag = model.BasicConsume(exchangeName + routing_key, false, consumer);
        }

        public static void send_Delay_EXCHANGE(string queueName)
        {
            var queueArgs = new Dictionary<string, object> {
                 { "x-dead-letter-exchange", queueName + "_EXCHANGE" },
                 { "x-dead-letter-routing-key", queueName + "_Delay" }
            };
            var model = RabbitMqConn.CreateModel();

            model.ExchangeDeclare(queueName + "_EXCHANGE", ExchangeType.Topic);
            model.QueueDeclare(queueName + "_Delay", false, false, false, null);
            model.QueueBind(queueName + "_Delay", queueName + "_EXCHANGE", queueName + "_Delay", null);

            model.QueueDeclare(queueName, false, false, false, queueArgs);
            model.QueueBind(queueName, queueName + "_EXCHANGE", queueName, null);

            var arguments = new Dictionary<string, object>();
            byte[] messageBodyBytes = Encoding.UTF8.GetBytes("Hello, world!");
            IBasicProperties props = model.CreateBasicProperties();
            props.Expiration = "20000";
            model.BasicPublish(queueName + "_EXCHANGE", queueName, props, messageBodyBytes);
            byte[] messageBodyBytes1 = Encoding.UTF8.GetBytes("Hello!");
            IBasicProperties props1 = model.CreateBasicProperties();
            props1.Expiration = "10000";
            //System.Threading.Thread.Sleep(10000);
            model.BasicPublish(queueName + "_EXCHANGE", queueName, props1, messageBodyBytes1);
        }


        public static void recieve(string queueName)
        {
            var model = RabbitMqConn.CreateModel();
            EventingBasicConsumer consumer = new EventingBasicConsumer(model);
            consumer.Received += (ch, ea) => {
                var body = Encoding.UTF8.GetString(ea.Body);
                Console.WriteLine(DateTime.Now.ToString() + body);
                // ... process the message
                model.BasicAck(ea.DeliveryTag, false);
            };
            string consumerTag = model.BasicConsume(queueName + "_Delay", false, consumer);

            //RabbitMqConn.Dispose();
        }
    }
}
