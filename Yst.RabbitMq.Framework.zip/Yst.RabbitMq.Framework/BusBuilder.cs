﻿using System;
using System.Configuration;
using EasyNetQ;
using Yst.Framework.RabbitMq.Logger;
using EasyNetQ.Consumer;
using EasyNetQ.Scheduling;

namespace Yst.Framework.RabbitMq
{
    /// <summary>
    /// 消息服务器连接器
    /// </summary>
    internal class BusBuilder
    {
        public static EasyNetQLogger Logger = new EasyNetQLogger();
        public static IBus CreateMessageBus()
        {
            // 消息服务器连接字符串
            string connString = ConfigurationManager.AppSettings["RabbitMQ"];
            if (string.IsNullOrEmpty(connString))
            {
                throw new Exception("RabbitMQ节点没有配置或者配置为空");
            }
            return RabbitHutch.CreateBus(connString, x => {
                x.Register<IEasyNetQLogger>(_ => Logger);
                x.Register<IConsumerErrorStrategy, ConsumerErrorStrategy>();
                x.Register<IScheduler, DelayedExchangeScheduler>();
                }
            );
        }

        public static int ThreadCount = int.Parse(ConfigurationManager.AppSettings["ConsumerThreadCount"] ?? "1");
    }
}
