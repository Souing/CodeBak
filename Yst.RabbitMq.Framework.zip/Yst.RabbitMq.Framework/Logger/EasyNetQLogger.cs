﻿using System;
using EasyNetQ;

namespace Yst.Framework.RabbitMq.Logger
{
    /// <summary>
    /// 日志级别
    /// </summary>
    enum LogLevel
    {
        None,
        Info,
        Debug,
        Error
    }

    public class EasyNetQLogger : IEasyNetQLogger
    {
        public void DebugWrite(string format, params object[] args)
        {
            RabbitMqLog.EasyNetQLogger.Info(format, args);
        }

        public void ErrorWrite(string format, params object[] args)
        {
            RabbitMqLog.EasyNetQLogger.Error(format, args);
        }

        public void ErrorWrite(Exception exception)
        {
            RabbitMqLog.EasyNetQLogger.Error(exception.ToString());
        }

        public void InfoWrite(string format, params object[] args)
        {
            RabbitMqLog.EasyNetQLogger.Info(format, args);
        }
    }
}
