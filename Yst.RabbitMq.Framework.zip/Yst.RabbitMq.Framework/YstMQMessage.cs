﻿namespace Yst.Framework.RabbitMq
{
    // ReSharper disable once InconsistentNaming
    public class YstMQMessage
    {
        public string Id { get; set; }
        public string Body { get; set; }

        public string Topic { get; set; }
    }
}
