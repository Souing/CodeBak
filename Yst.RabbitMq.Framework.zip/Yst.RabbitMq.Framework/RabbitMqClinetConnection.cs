﻿using RabbitMQ.Client;

namespace Yst.Framework.RabbitMq
{
    public class RabbitMqClinetConnection
    {
        public static IConnection CreateConnection()
        {
            ConnectionFactory factory = new ConnectionFactory();
            factory.UserName = "guest";
            factory.Password = "guest";
            factory.VirtualHost = "/";
            factory.HostName = "10.153.29.11";
            factory.Port = 5672;
            IConnection conn = factory.CreateConnection();
            return conn;
        }
    }
}